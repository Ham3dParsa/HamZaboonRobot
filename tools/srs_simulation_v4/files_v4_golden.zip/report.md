# SRS v4 Simulation Report

## 1. Scenario Matrix (plan x persona x proficiency, 360 days)

| plan | persona | proficiency | active_words | learned | learned/$ | AI$ | max_due | max_qbl | avg_late |
|---|---|---|---|---|---|---|---|---|---|
| free | lazy | beginner | 53 | 53 | 874.6 | 0.0606 | 18 | 2 | 2.9 |
| free | lazy | intermediate | 50 | 49 | 735.7 | 0.0666 | 20 | 3 | 2.8 |
| free | lazy | advanced | 45 | 45 | 714.3 | 0.063 | 20 | 3 | 3.1 |
| free | average | beginner | 137 | 131 | 843.0 | 0.1554 | 19 | 7 | 0.7 |
| free | average | intermediate | 119 | 118 | 898.0 | 0.1314 | 20 | 7 | 1.0 |
| free | average | advanced | 123 | 117 | 805.8 | 0.1452 | 13 | 8 | 0.6 |
| free | eager | beginner | 165 | 159 | 1113.4 | 0.1428 | 10 | 8 | 0.3 |
| free | eager | intermediate | 165 | 159 | 1113.4 | 0.1428 | 10 | 8 | 0.3 |
| free | eager | advanced | 165 | 159 | 1113.4 | 0.1428 | 10 | 8 | 0.3 |
| free | fluctuating | beginner | 113 | 110 | 773.6 | 0.1422 | 16 | 7 | 1.1 |
| free | fluctuating | intermediate | 109 | 107 | 818.0 | 0.1308 | 25 | 7 | 1.6 |
| free | fluctuating | advanced | 109 | 107 | 818.0 | 0.1308 | 25 | 7 | 1.6 |
| silver | lazy | beginner | 154 | 151 | 1204.1 | 0.1254 | 65 | 2 | 3.5 |
| silver | lazy | intermediate | 176 | 162 | 937.5 | 0.1728 | 64 | 2 | 2.8 |
| silver | lazy | advanced | 174 | 166 | 904.1 | 0.1836 | 56 | 2 | 2.9 |
| silver | average | beginner | 387 | 377 | 1061.4 | 0.3552 | 40 | 11 | 0.8 |
| silver | average | intermediate | 357 | 347 | 909.3 | 0.3816 | 56 | 13 | 1.0 |
| silver | average | advanced | 365 | 356 | 922.8 | 0.3858 | 38 | 7 | 0.8 |
| silver | eager | beginner | 537 | 522 | 1099.9 | 0.4746 | 38 | 32 | 0.3 |
| silver | eager | intermediate | 537 | 522 | 1076.7 | 0.4848 | 46 | 31 | 0.3 |
| silver | eager | advanced | 537 | 522 | 1076.7 | 0.4848 | 46 | 31 | 0.3 |
| silver | fluctuating | beginner | 341 | 335 | 1013.3 | 0.3306 | 60 | 9 | 1.5 |
| silver | fluctuating | intermediate | 306 | 297 | 937.5 | 0.3168 | 76 | 8 | 2.0 |
| silver | fluctuating | advanced | 304 | 294 | 938.7 | 0.3132 | 67 | 11 | 2.2 |
| gold | lazy | beginner | 282 | 281 | 1255.6 | 0.2238 | 90 | 2 | 3.3 |
| gold | lazy | intermediate | 289 | 277 | 1010.2 | 0.2742 | 108 | 3 | 3.2 |
| gold | lazy | advanced | 302 | 295 | 1007.5 | 0.2928 | 94 | 3 | 3.0 |
| gold | average | beginner | 708 | 675 | 1119.4 | 0.603 | 77 | 11 | 0.9 |
| gold | average | intermediate | 690 | 667 | 982.9 | 0.6786 | 105 | 10 | 0.9 |
| gold | average | advanced | 691 | 674 | 969.2 | 0.6954 | 74 | 6 | 0.9 |
| gold | eager | beginner | 987 | 960 | 1111.9 | 0.8634 | 52 | 45 | 0.3 |
| gold | eager | intermediate | 961 | 923 | 1096.5 | 0.8418 | 51 | 41 | 0.4 |
| gold | eager | advanced | 962 | 938 | 1083.4 | 0.8658 | 73 | 44 | 0.3 |
| gold | fluctuating | beginner | 559 | 542 | 1133.4 | 0.4782 | 135 | 8 | 2.1 |
| gold | fluctuating | intermediate | 563 | 559 | 1021.6 | 0.5472 | 157 | 8 | 2.0 |
| gold | fluctuating | advanced | 597 | 584 | 965.6 | 0.6048 | 122 | 9 | 1.7 |
| platinum | lazy | beginner | 526 | 524 | 1307.4 | 0.4008 | 175 | 4 | 3.4 |
| platinum | lazy | intermediate | 530 | 502 | 1038.0 | 0.4836 | 253 | 3 | 4.0 |
| platinum | lazy | advanced | 483 | 480 | 1034.9 | 0.4638 | 159 | 2 | 3.3 |
| platinum | average | beginner | 1228 | 1211 | 1217.3 | 0.9948 | 121 | 12 | 0.7 |
| platinum | average | intermediate | 1179 | 1129 | 1020.4 | 1.1064 | 184 | 9 | 1.0 |
| platinum | average | advanced | 1184 | 1172 | 1021.1 | 1.1478 | 134 | 10 | 0.8 |
| platinum | eager | beginner | 1699 | 1642 | 1221.2 | 1.3446 | 105 | 28 | 0.4 |
| platinum | eager | intermediate | 1679 | 1649 | 1135.2 | 1.4526 | 99 | 28 | 0.3 |
| platinum | eager | advanced | 1744 | 1691 | 1096.2 | 1.5426 | 74 | 23 | 0.2 |
| platinum | fluctuating | beginner | 1063 | 1022 | 1197.8 | 0.8532 | 204 | 9 | 1.6 |
| platinum | fluctuating | intermediate | 988 | 974 | 1024.2 | 0.951 | 209 | 6 | 1.9 |
| platinum | fluctuating | advanced | 1071 | 1056 | 1026.8 | 1.0284 | 208 | 11 | 1.7 |

## 2. Feature Toggle Isolation (gold/eager/advanced, 360 days)

| config | learned | avg_stability_days | max_due | AI$ | learned/$ |
|---|---|---|---|---|---|
| all features ON (default) | 938 | 103.44 | 73 | 0.8658 | 1083.4 |
| rejection OFF | 962 | 105.08 | 53 | 0.8586 | 1120.4 |
| catchup OFF | 939 | 102.87 | 65 | 0.8682 | 1081.5 |
| continuous_mastery OFF (legacy binary) | 697 | 128.05 | 49 | 0.6624 | 1052.2 |
| session_rate_limit OFF | 938 | 103.44 | 73 | 0.8658 | 1083.4 |
| all OFF (pure v3 legacy mode) | 727 | 130.17 | 65 | 0.6546 | 1110.6 |

## 3. Premium Config Override Band (+/-30%, gold plan defaults: 4 sessions x 7 cards)

| requested sessions | requested size | effective sessions | effective size | note |
|---|---|---|---|---|
| 4 | 7 | 4 | 7 | baseline (no override) |
| 5 | 9 | 5 | 9 | within +30% band -> honored |
| 6 | 12 | 6 | 10 | above +30% band -> clamped to +30% |
| 2 | 4 | 2 | 4 | below -30% band -> clamped to -30% |
| 1 | 1 | 2 | 4 | far below band -> clamped, floor 1 |

## 3b. Mid-run Config Change (user edits session/size settings partway through)

Phase A: days 0-180 at gold defaults (4x7). Phase B: days 180-360, user bumps to +30% band (5x9 requested -> clamped).

- Phase A (4x7): learned=387, max_due=75, AI$=0.378
- Phase B (clamped to 5x9): learned=575, max_due=123, AI$=0.5736
- Result: override band clamps the request to +30% (5x9 is exactly the +30% edge for 4x7 -> stays within [3,5] sessions and [5,9] size), system remains stable, no crash or runaway backlog.

## 4. Long-Run Stress Test (720 days)

| plan | persona | learned | learned/$ | max_due | max_qbl | avg_late | max_late | AI$ total |
|---|---|---|---|---|---|---|---|---|
| free | lazy | 89 | 706.3 | 18 | 4 | 2.7 | 14 | 0.126 |
| free | eager | 298 | 1121.1 | 9 | 8 | 0.2 | 3 | 0.2658 |
| gold | lazy | 517 | 1011.3 | 153 | 4 | 3.2 | 17 | 0.5112 |
| gold | eager | 1688 | 1132.1 | 60 | 49 | 0.3 | 3 | 1.491 |
| gold | fluctuating | 1019 | 994.3 | 123 | 19 | 1.8 | 10 | 1.0248 |

**Check**: no combination should show max_due_backlog growing unboundedly relative to queue_cap_days x daily_slots, and max_query_backlog should stay finite (queries eventually get drained by the self-correcting split even under lazy attendance), confirming bug 2/1 fixes hold at scale.

## 5. Learning Curve Over Time (gold/average/intermediate)

| day checkpoint | active_words | learned | avg_stability_days | AI$ cumulative |
|---|---|---|---|---|
| 30 | 105 | 72 | 7.87 | 0.099 |
| 90 | 222 | 197 | 22.67 | 0.2028 |
| 180 | 398 | 384 | 44.56 | 0.3846 |
| 360 | 690 | 667 | 88.48 | 0.6786 |
| 720 | 1175 | 1147 | 180.38 | 1.1772 |

## 6. v3-legacy-equivalent vs v4-full (360 days, matrix of personas)

| persona | mode | learned | avg_stability_days | max_due | AI calls | AI$ |
|---|---|---|---|---|---|---|
| lazy | v3-legacy | 86 | 41.51 | 56 | 124 | 0.0744 |
| lazy | v4-full   | 295 | 55.89 | 94 | 488 | 0.2928 |
| average | v3-legacy | 309 | 113.18 | 62 | 523 | 0.3138 |
| average | v4-full   | 674 | 87.67 | 74 | 1159 | 0.6954 |
| eager | v3-legacy | 727 | 130.17 | 65 | 1091 | 0.6546 |
| eager | v4-full   | 938 | 103.44 | 73 | 1443 | 0.8658 |
| fluctuating | v3-legacy | 299 | 111.99 | 80 | 501 | 0.3006 |
| fluctuating | v4-full   | 584 | 91.93 | 122 | 1008 | 0.6048 |

## 7. Plan Tier Benchmark — learned words at 3/6/12 months (eager, intermediate)

Daily slots = sessions x session_size. Eager persona used as the target audience for this comparison (a plan's ceiling only matters to users who actually hit it).

| plan | slots/day | 3mo learned | 6mo learned | 12mo learned | 12mo AI$ | 12mo max_due |
|---|---|---|---|---|---|---|
| free | 4 | 50 | 85 | 159 | 0.1428 | 10 |
| silver | 15 | 157 | 291 | 522 | 0.4848 | 46 |
| gold | 28 | 282 | 497 | 923 | 0.8418 | 51 |
| platinum | 50 | 519 | 940 | 1649 | 1.4526 | 99 |

**New tier note**: `platinum` (name not locked) targets very-eager learners: 5 sessions x 10 cards = 50 slots/day, ~1.8x gold's 28. This produces a proportional (~80%) jump in learned words at every checkpoint, not an arbitrary 'because it's the top tier' boost — the gain tracks the extra review capacity a real heavy user would actually put in, keeping the plan realistic rather than aspirational.
